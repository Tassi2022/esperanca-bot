import sqlite3
from datetime import datetime
from pathlib import Path

DB_PATH = Path(__file__).parent / "esperanca.db"


def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS oportunidades (
        id TEXT PRIMARY KEY,
        usuario TEXT,
        texto TEXT,
        hashtag TEXT,
        link TEXT,
        resposta TEXT,
        urgente INTEGER DEFAULT 0,
        respondida INTEGER DEFAULT 0,
        criado_em TEXT
    )""")
    conn.commit()
    conn.close()


def salvar_oportunidade(post, resposta):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(
        "INSERT OR IGNORE INTO oportunidades "
        "(id,usuario,texto,hashtag,link,resposta,urgente,respondida,criado_em) "
        "VALUES (?,?,?,?,?,?,?,?,?)",
        (
            post["id"],
            post.get("usuario", "@usuario"),
            post["texto"],
            post["hashtag_origem"],
            post["link"],
            resposta,
            1 if post.get("urgente") else 0,
            0,
            datetime.now().strftime("%d/%m %H:%M"),
        ),
    )
    conn.commit()
    conn.close()


def listar_oportunidades(filtro="todas"):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    if filtro == "urgentes":
        c.execute("SELECT * FROM oportunidades WHERE urgente=1 AND respondida=0 ORDER BY criado_em DESC")
    elif filtro == "pendentes":
        c.execute("SELECT * FROM oportunidades WHERE respondida=0 ORDER BY criado_em DESC")
    elif filtro == "respondidas":
        c.execute("SELECT * FROM oportunidades WHERE respondida=1 ORDER BY criado_em DESC")
    else:
        c.execute("SELECT * FROM oportunidades ORDER BY urgente DESC, criado_em DESC")
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows


def marcar_respondida(op_id, valor):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("UPDATE oportunidades SET respondida=? WHERE id=?", (valor, op_id))
    conn.commit()
    conn.close()


def stats():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT COUNT(*) FROM oportunidades")
    total = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM oportunidades WHERE urgente=1 AND respondida=0")
    urgentes = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM oportunidades WHERE respondida=1")
    respondidas = c.fetchone()[0]
    conn.close()
    taxa = round((respondidas / total * 100)) if total > 0 else 0
    return {"total": total, "urgentes": urgentes, "respondidas": respondidas, "taxa": taxa}


init_db()
