PIZZARIA_NOME = "Pizzaria A EsperancA"
PIZZARIA_HISTORIA = (
    "Fundada em 1957 por uma familia italiana em Sao Paulo, "
    "ha mais de 25 anos no Jardim da Saude. "
    "Mais de 1 milhao de clientes e 5 mil familias atendidas por semana. "
    "Entrega feita pelos proprios funcionarios, sem terceiros."
)
PIZZARIA_IFOOD = "https://ifoodbr.onelink.me/F4X4/AEsperancaPizzaria"
PIZZARIA_BAIRRO = "Jardim da Saude"
PIZZARIA_CIDADE = "Sao Paulo"

HASHTAGS = [
    "pizzadeliverysp",
    "pizzasp",
    "jardimdasaude",
    "pizzasaopaulo",
    "zonasulsp",
]

PALAVRAS_CHAVE = [
    "com fome",
    "quero pizza",
    "pedir pizza",
    "bora pedir",
    "to com fome",
    "tô com fome",
    "vontade de comer",
    "pizza hoje",
    "pede pizza",
    "que fome",
    "indica",
    "indicacao",
    "qual pizzaria",
    "onde pedir",
    "delivery bom",
]

PALAVRAS_URGENTES = [
    "indica",
    "indicacao",
    "qual pizzaria",
    "onde pedir",
    "com fome",
    "quero pizza",
    "que fome",
    "vontade de comer",
]

PALAVRAS_IGNORAR = [
    "peça ja",
    "peca ja",
    "ligue agora",
    "cardapio",
    "novidade",
    "promoção",
    "promocao",
    "desconto",
    "delivery aberto",
    "estamos abertos",
    "link na bio",
    "pedido minimo",
    "taxa de entrega",
    "whatsapp",
    "encomenda",
    "sabor do mes",
]

ZAPI_INSTANCE_ID = "3F351E2384D45138223DCEFB423F3906"
ZAPI_TOKEN = "5384CACFE5E8A06C5391CD0A"
WHATSAPP_DESTINO = "5511978855916"

HORARIO_RELATORIO = "22:00"
INTERVALO_VARREDURA_MINUTOS = 30

GEMINI_API_KEY = "AIzaSyCKXMcgbBBZT9Hq2sXXTwUucrCsKuJMN3Y"

# RapidAPI (Instagram Scraper Stable API)
RAPIDAPI_KEY = "e7ddbb8d15msh2d3a66faf7bcfd6p175ea8jsna0e072e97f40"
RAPIDAPI_HOST = "instagram-scraper-stable-api.p.rapidapi.com"
