from flask import Flask, render_template, jsonify, request
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from database import listar_oportunidades, marcar_respondida, stats

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("dashboard.html")


@app.route("/api/oportunidades")
def api_oportunidades():
    filtro = request.args.get("filtro", "todas")
    return jsonify(listar_oportunidades(filtro))


@app.route("/api/stats")
def api_stats():
    return jsonify(stats())


@app.route("/api/responder/<op_id>", methods=["POST"])
def api_responder(op_id):
    valor = request.json.get("valor", 1)
    marcar_respondida(op_id, valor)
    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(debug=True)
