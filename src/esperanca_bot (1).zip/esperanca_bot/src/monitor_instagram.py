import requests
import logging
from datetime import datetime
from typing import List, Dict

logger = logging.getLogger(__name__)

# Importa chaves do settings
from config.settings import RAPIDAPI_KEY, RAPIDAPI_HOST

HEADERS = {
    "Content-Type": "application/json",
    "x-rapidapi-host": RAPIDAPI_HOST,
    "x-rapidapi-key": RAPIDAPI_KEY,
}


def buscar_posts_hashtag(hashtag: str, max_posts: int = 20) -> List[Dict]:
    """Busca posts de uma hashtag via RapidAPI."""
    url = f"https://{RAPIDAPI_HOST}/search_hashtag.php"
    params = {"hashtag": hashtag}

    posts = []
    try:
        resp = requests.get(url, headers=HEADERS, params=params, timeout=30)
        resp.raise_for_status()
        data = resp.json()

        # A API pode retornar lista direto ou dentro de uma chave
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            items = (
                data.get("data")
                or data.get("posts")
                or data.get("items")
                or data.get("response", {}).get("data", [])
                or []
            )
        else:
            logger.warning(f"#{hashtag}: formato inesperado: {type(data)}")
            return []

        if not items:
            logger.warning(f"#{hashtag}: sem dados retornados")
            return []

        for item in items[:max_posts]:
            shortcode = (
                item.get("shortcode")
                or item.get("short_code")
                or item.get("code")
                or item.get("id", "")
            )
            if not shortcode:
                continue

            caption = (
                item.get("caption")
                or item.get("text")
                or item.get("edge_media_to_caption", {})
                    .get("edges", [{}])[0]
                    .get("node", {})
                    .get("text", "")
                or ""
            )

            owner = item.get("owner") or item.get("user") or {}
            usuario = (
                owner.get("username")
                or item.get("username")
                or item.get("user_name")
                or "@usuario"
            )

            posts.append({
                "id": str(shortcode),
                "shortcode": str(shortcode),
                "link": f"https://www.instagram.com/p/{shortcode}/",
                "texto": caption[:400],
                "usuario": usuario,
                "timestamp": datetime.now().timestamp(),
                "hashtag_origem": hashtag,
            })

        logger.info(f"#{hashtag}: {len(posts)} posts encontrados")

    except requests.exceptions.HTTPError as e:
        logger.error(f"Erro HTTP #{hashtag}: {e.response.status_code} - {e.response.text[:200]}")
    except requests.exceptions.RequestException as e:
        logger.error(f"Erro de conexão #{hashtag}: {e}")
    except Exception as e:
        logger.error(f"Erro inesperado #{hashtag}: {e}")

    return posts


def filtrar_posts_relevantes(
    posts: List[Dict],
    palavras_chave: List[str],
    palavras_urgentes: List[str],
) -> List[Dict]:
    """Filtra posts relevantes para o negócio."""
    try:
        from config.settings import PALAVRAS_IGNORAR
    except ImportError:
        PALAVRAS_IGNORAR = []

    relevantes = []
    vistos = set()

    for post in posts:
        if post["id"] in vistos:
            continue
        vistos.add(post["id"])

        texto_lower = post["texto"].lower()

        if any(p.lower() in texto_lower for p in PALAVRAS_IGNORAR):
            continue

        if not any(p.lower() in texto_lower for p in palavras_chave):
            continue

        post["urgente"] = any(u.lower() in texto_lower for u in palavras_urgentes)
        post["timestamp_fmt"] = datetime.now().strftime("%d/%m %H:%M")
        relevantes.append(post)

    return relevantes


def coletar_todas_hashtags(
    hashtags: List[str],
    palavras_chave: List[str],
    palavras_urgentes: List[str],
) -> List[Dict]:
    """Coleta e filtra posts de todas as hashtags configuradas."""
    todos = []
    ids_vistos = set()

    for hashtag in hashtags:
        posts = buscar_posts_hashtag(hashtag)
        for post in filtrar_posts_relevantes(posts, palavras_chave, palavras_urgentes):
            if post["id"] not in ids_vistos:
                ids_vistos.add(post["id"])
                todos.append(post)

    todos.sort(key=lambda x: (not x["urgente"], -x["timestamp"]))
    logger.info(f"Total coletado: {len(todos)} posts relevantes")
    return todos
